 <footer id="footer" class="midnight-blue">
     <div class="container">
         <div class="row">
             <div class="col-sm-11">
                <center> &copy; 2019 <a target="_blank" href="http://shapebootstrap.net/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">Sistem Informasi Pemasaran UKM Desa Tritiro</a>. All Rights Reserved. </center>
             </div>
         </div>
     </div>
 </footer>

 <script src="../../assets/js/jquery.js"></script>
 <script src="../../assets/js/bootstrap.min.js"></script>
 <script src="../../assets/js/jquery.prettyPhoto.js"></script>
 <script src="../../assets/js/owl.carousel.min.js"></script>
 <script src="../../assets/js/jquery.isotope.min.js"></script>
 <script src="../../assets/js/main.js"></script>
 </body>

 </html>