<!-- untuk head -->
<?php include_once 'atribut/head.php' ?>

<!-- untuk menu -->
<?php include_once 'atribut/menu.php' ?>

<!-- untuk konten -->

    <section class="konten">
        <div class="container">
            <h1>Profil UKM Desa Tritiro</h1>
            

                <?php $ambil = $koneksi->query("SELECT * FROM profilukm"); ?>
                <?php while ($perprofil = $ambil->fetch_assoc()) { ?>

                    <div class="row" width="1000" height="1500">
                    <div class="col-md-50">
                        <div class="thumbnail" >
                            <div class="caption">
                                <h2><?php echo $perprofil['nama_ukm']; ?></h2>
                                <h3><img src="../../pictures/foto_profil_ukm/<?php echo $perprofil['fotostruktural']; ?>" alt=""></h3>
                                <h4><?php echo $perprofil['nomorhp']; ?></h4>
                                <h5><?php echo $perprofil['alamat_lengkap']; ?></h5>
                            </div>
                        </div>
                    </div>
                     <a href="profilukm.php" class="btn btn-primary">Kembali</a> <br><br>
                <?php } ?>
            </div>
        </div>  
    </section>

<!-- untuk foot -->
<?php include_once 'atribut/foot.php' ?>