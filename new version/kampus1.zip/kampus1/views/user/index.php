<!-- untuk head -->
<?php include_once 'atribut/head.php' ?>

<!-- untuk menu -->
<?php include_once 'atribut/menu.php' ?>

<!-- untuk slider -->
<div id="tes-carousel" class="carousel slide" data-ride="carousel">
    <!-- indikator -->
    <ol class="carousel-indicators">
        <li data-target="#tes-carousel" data-slide-to="0" class="active"></li>
        <li data-target="#tes-carousel" data-slide-to="1"></li>
        <li data-target="#tes-carousel" data-slide-to="2"></li>
        <li data-target="#tes-carousel" data-slide-to="3"></li>
        <li data-target="#tes-carousel" data-slide-to="4"></li>
        <li data-target="#tes-carousel" data-slide-to="5"></li>
        <li data-target="#tes-carousel" data-slide-to="6"></li>
    </ol>

    <div class="carousel-inner">

        <!-- slide 1 -->
        <div class="item active">
            <img src="../../assets/images/slider/111.PNG" alt="Demo 1" class="img-responsive" style="width: 100%" />
            <!-- caption -->
            <div class="carousel-caption">
                <h1>UKM Atap Konjo</h1>
            </div>
        </div>

        <!-- slide 2 -->
        <div class="item">
            <img src="../../assets/images/slider/ktr.png" alt="Demo 2" class="img-responsive" style="width: 100%" />
            <!-- caption -->
            <div class="carousel-caption">
                <h1>UKM Kalongkong Tiro</h1>
            </div>
        </div>

        <!-- slide 3 -->
        <div class="item">
            <img src="../../assets/images/slider/3.jpg" alt="Demo 3" class="img-responsive" style="width: 100%" />
            <!-- caption -->
            <div class="carousel-caption">
                <h1>UKM Menjahit</h1>
            </div>
        </div>

        <!-- slide 4-->
        <div class="item">
            <img src="../../assets/images/slider/n1.jpg" alt="Demo 3" class="img-responsive" style="width: 100%" />
            <!-- caption -->
            <div class="carousel-caption">
                <h1>UKM Nelayan Kecil</h1>
            </div>
        </div>

        <!-- slide 5 -->
        <div class="item">
            <img src="../../assets/images/slider/p1.jpg" alt="Demo 3" class="img-responsive" style="width: 100%" />
            <!-- caption -->
            <div class="carousel-caption">
                <h1>UKM Pedagang Kecil</h1>
            </div>
        </div>

        <!-- slide 6 -->
        <div class="item">
            <img src="../../assets/images/slider/k1.jpg" alt="Demo 3" class="img-responsive" style="width: 100%" />
            <!-- caption -->
            <div class="carousel-caption">
                <h1>UKM Kuliner</h1>
            </div>
        </div>

    </div>

    <!-- kontrol-->
    <a class="carousel-control left" href="#tes-carousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control right" href="#tes-carousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<section id="testimonial">
    <div class="container">
        <div class="center fadeInDown">
            <h2>Penggagas UKM Desa Tritiro</h2>
            <p class="lead">Berikut ada beberapa penggagas UKM Desa Tritiro yang berjasa dalam pengembangan produk UKM
                Desa <br>
                Terima kasih atas Support membangunnya dan Semoga berkah untuk Kita Semua<br>
                Mari Majukan Produk Lokal Peninggalan Para Leluhur Kita !
            </p>
        </div>
        <div class="testimonial-slider owl-carousel">
            <div class="single-slide">
                <div class="slide-img">
                    <img src="../../assets/images/33.jpeg" width=145 height=100 alt="">
                    </div>
                    <div class="content">
                        <img src="assets/images/review.png" alt="">
                        <p>Realisasi takkan tercapai apabila hanya berpangku Kaki dengan penuh Khayalan, Tetaplah brdoa
                            dan berusaha berguna bagi sesama.</p>
                        <h4>- Yuyun Wahyuni</h4>
                </div>
            </div>
            <div class="single-slide">
                <div class="slide-img">
                    <img src="../../assets/images/4.jpeg" width=145 height=100 alt="">
                </div>
                <div class="content">
                    <img src="../../assets/images/review.png" alt="">
                    <p>Majukan Desa makmurkan ekonomi Masyarakat</p>
                    <h4>- Saiful Amar SE</h4>
                </div>
            </div>
            <div class="single-slide">
                <div class="slide-img">
                    <img src="../../assets/images/2.png" width=145 height=100 alt="">
                </div>
                <div class="content">
                    <img src="../../assets/images/review.png" alt="">
                    <p>Tidak Ada Usaha yang Mengkhianati Hasil, Tetap Berdoa dan berikhtiar</p>
                        <h4>- Bau Darmawati</h4>
                </div>
            </div>
            <div class="single-slide">
                <div class="slide-img">
                    <img src="../../assets/images/client2.jpg" alt="">
                </div>
                <div class="content">
                    <img src="../../assets/images/review.png" alt="">
                    <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in
                        price.</p>
                    <h4>- Charlotte Daniels</h4>
                </div>
            </div>
            <div class="single-slide">
                <div class="slide-img">
                    <img src="../../assets/images/client1.jpg" alt="">
                </div>
                <div class="content">
                    <img src="../../assets/images/review.png" alt="">
                    <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in
                        price.</p>
                    <h4>- Charlotte Daniels</h4>
                </div>
            </div>
            <div class="single-slide">
                <div class="slide-img">
                    <img src="../../assets/images/client3.jpg" alt="">
                </div>
                <div class="content">
                    <img src="../../assets/images/review.png" alt="">
                    <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in
                        price.</p>
                    <h4>- Charlotte Daniels</h4>
                </div>
            </div>
        </div>
    </div>
</section>

 <br>
    <br>
    <br>
    <section id="bottom">
        <div class="container fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="row">
                <div class="col-md-2">
                    <a href="#" class="footer-logo">
                        <img src="../../assets/images/ico/bulkum.ico" alt="logo">
                    </a>
                </div>
                <div class="col-md-10">
                    <div class="row">
                        <div class="col-md-3 col-sm-6">
                            <div class="widget">
                                <center>
                                    <h3>Tentang Kami</h3>
                                </center>
                                <ul>
                                    <div class="content">
                                        <p>UKM Desa Tritiro merupakan Salah satu UKM yang ada di ada di Kecamatan Bontotiro, Kabupaten Bulukumba, Sulawesi Selatan 
                                            yang memiliki 6 UKM yaitu Atap Konjo, Kalongkong Tiro, Menjahit, Pedagang Kecil, Nelayan Kecil dan Kuliner </p>
                                    </div>
                                </ul>
                            </div>
                        </div>
                        <!--/.col-md-3-->
                        <div class="col-md-3 col-sm-6">
                            <div class="widget">
                                <center>
                                    <h3>Informasi</h3>
                                </center>
                                <ul>
                                    <div class="content">
                                    </div>
                                    Jalan Pendidikan desa Tritiro, Kecamatan Bontotiro Kabupaten Bulukumba
                                    Hari dan Jam Layanan Pelanggan:
                                    Senin - Sabtu 08.00 - 20.00 WIB
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="widget">
                                <center>
                                    <h3>Kontak UKM</h3>
                                </center>
                                <ul>
                                    <div class="content">
                                    </div>
                                    UKM Atap Konjo : 085656209762(Yuyun Wahyuni) <br>
                                    UKM Menjahit : 085298409217(Bau Darmawati)<br>
                                    UKM Kalongkong Tiro : 081331356093(Mustan)<br>
                                    UKM Nelayan Kecil : 085756367377(Suriani)<br>
                                    UKM Pedagang Kecil : 08224549954<br>
                                    UKM Kuliner : 082192140107(Yuyun Wahyuni)<br>
                                </ul>
                            </div>
                        </div>
                        <!--/.col-md-3-->

                        <div class="col-md-3 col-sm-10">
                            <div class="widget">
                                <center>
                                    <h3>Rekening BANK UKM Atap Konjo</h3>
                                </center>
                                <ul>
                                    <div class="content">
                                      Atas Nama <br>
                                        Yuyun Wahyuni <br>
                                        BRI: 0253-01-0173595-04<br>  
                                    </div>
                                </ul>
                            </div>
                        </div>
                        <!--/.col-md-3-->

                    </div>
                </div>


            </div>
        </div>
    </section>

<!-- untuk foot -->
<?php include_once 'atribut/foot.php' ?>