<?php include_once '../../configs/koneksi.php'; ?>
<html>
<head>
	<title>CETAK PRINT DATA DARI LAPORAN KEUANGAN</title>
</head>
<body>
 
	<center>
		<h2>DATA LAPORAN KEUANGAN</h2>
	
	</center>
 
	<table border="1" style="width: 100%">
		<tr>
			<th width="1%">No</th>
			<th>Nama Pelanggan</th>
			<th>Tanggal</th>
			<th>Nama Produk</th>
			<th>Jumlah</th>
		</tr>

		<?php 
		$no = 1;
		$sql = mysqli_query($koneksi,"SELECT pembelian.*, tb_user.nama as nama_pelanggan, produk.*, pembelian_produk.* 
		FROM pembelian_produk LEFT JOIN pembelian ON pembelian_produk.id_pembelian = pembelian.id_pembelian 
		LEFT JOIN tb_user ON pembelian.id_pelanggan = tb_user.id_user LEFT JOIN produk ON pembelian_produk.id_produk = produk.id_produk");
		$total = 0;
		while($data = mysqli_fetch_array($sql)){
			$total+=$data['subharga'];
		?>
		<tr>
			<td><?= $no++; ?></td>
			<td><?= $data['nama_pelanggan']; ?></td>
			<td align="center"><?= $data['tanggal_pembelian']; ?></td>
			<td><?= $data['nama_produk']; ?></td>
			<td>Rp. <?= number_format($data['subharga']); ?></td>
		</tr>
		<?php } ?>
	<tfoot>
        <tr>
            <th colspan="4">Total</th>
            <th>Rp. <?= number_format($total) ?></th>
            <th></th>
        </tr>
    </tfoot>
	</table>
 
	<script>
		window.print();
	</script>
 
</body>
</html>