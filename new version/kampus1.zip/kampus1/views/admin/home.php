<marquee>
<h2> Selamat Datang di Halaman Administrator Sistem Informasi Usaha Kecil dan Menengah (UKM) Desa Tritiro Kabupaten Bulukumba</h2>
</marquee>
