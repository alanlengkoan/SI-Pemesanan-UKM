
<html>
<head>
<title>Form Komentar</title>
<h3><center>Tuliskan Komentar</center></h3>
<hr>
<body>
<form action="konfirmasi.php" method="post">
Nama   :<br> <input type="text" name="nama"><br>
E-Mail :<br> <input type="text" name="email"><br>
Isi    : <br>
<textarea name="komentar" cols="100" rows="50"> </textarea><br>
<input type="submit" value="Kirim">
<input type="reset" value="Batal">
</body>
</html>