<!DOCTYPE html>
<html>
<head>
	<title>Lightbox Photo Gallery</title>

    <!-- Bootstrap CDN -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

    <!-- Ekko Lightbox -->
	<link href ="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" rel = "stylesheet" crossorigin="anonymous">
    <script src = "https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js" crossorigin="anonymous"></script>

    <!-- Custom CSS -->
    <link href = "styles.css" rel = "stylesheet">
    .imggallery{
    max-height: 250px;
        }

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<body>
      <div id = "gallery">
           <div class = "row text-center">
                  <div class = "col-md-4"></div>
                  <div class = "col-md-4"></div>
                  <div class = "col-md-4"></div>
           </div>
      </div>
</body>
<a href = "[link foto]" data-toggle="lightbox" data-gallery="gallery">
     <img src = "[link foto]" class = "imggallery">
     body>
    <div id = "gallery">
        <div class = "row text-center">
            
            <div class = "col-md-4">
                <a href = "https://images.pexels.com/photos/1029844/pexels-photo-1029844.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" data-toggle = "lightbox" data-gallery="gallery">
                    <img src = "https://images.pexels.com/photos/1029844/pexels-photo-1029844.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" class= "imggallery">
                </a>
            </div>

            <div class = "col-md-4">
                <a href = "https://images.pexels.com/photos/892612/pexels-photo-892612.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" data-toggle = "lightbox" data-gallery="gallery">
                    <img src = "https://images.pexels.com/photos/892612/pexels-photo-892612.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" class = "imggallery">
                </a>
            </div>


            <div class = "col-md-4">
                <a href = "https://images.pexels.com/photos/1029794/pexels-photo-1029794.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" data-toggle = "lightbox" data-gallery="gallery">
                    <img src = "https://images.pexels.com/photos/1029794/pexels-photo-1029794.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" class = "imggallery">
                </a>
            </div>
            <script>
  $(document).on("click", '[data-toggle="lightbox"]', function(event){
    event.preventDefault();
    $(this).ekkoLightbox();
  });
</script>





</head>
</html>