-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Sep 2019 pada 11.28
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `si_ukmdesatritiro`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `ongkir`
--

CREATE TABLE `ongkir` (
  `id_ongkir` int(11) NOT NULL,
  `nama_kota` varchar(100) NOT NULL,
  `tarif` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ongkir`
--

INSERT INTO `ongkir` (`id_ongkir`, `nama_kota`, `tarif`) VALUES
(1, 'Makassar', 25000),
(2, 'Bulukumba', 15000),
(3, 'Gowa', 25000),
(4, 'Jeneponto', 20000),
(5, 'Takalar', 20000),
(6, 'Bantaeng', 15000),
(7, 'Sinjai', 20000),
(8, 'Bone', 25000),
(9, 'Sidrap', 30000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_pembelian`, `nama`, `bank`, `jumlah`, `tanggal`, `bukti`) VALUES
(4, 4, 'Lince bidang', 'BTN', 95000, '2019-09-10', 'IMG-20190625-WA0042.jpg'),
(5, 6, 'Lince bidang', 'BRI', 510000, '2019-09-11', '69760175_1310243419145803_928347873836269568_n.jpg'),
(6, 5, 'Lince bidang', 'BTN', 30000, '2019-09-18', '2. user manajemen.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `id_ongkir` int(11) NOT NULL,
  `tanggal_pembelian` date NOT NULL,
  `total_pembelian` int(11) NOT NULL,
  `nama_kota` varchar(100) NOT NULL,
  `tarif` int(11) NOT NULL,
  `alamat_pengiriman` text NOT NULL,
  `status_pembelian` varchar(100) NOT NULL DEFAULT 'pending',
  `resi_pengiriman` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `id_pelanggan`, `id_ongkir`, `tanggal_pembelian`, `total_pembelian`, `nama_kota`, `tarif`, `alamat_pengiriman`, `status_pembelian`, `resi_pengiriman`) VALUES
(1, 2, 1, '2019-08-20', 920000, 'Makassar', 20000, 'Jalan Bontobila VII No 2 Makassar, batua kecamatan Manggala', 'barang dikirim', '78GHK5R8U'),
(2, 4, 1, '2019-08-26', 135000, 'Makassar', 20000, 'Jalan Lompeteke Dusun Kalumpang Utara Desa Tritiro', 'sudah kirim pembayaran', NULL),
(3, 4, 1, '2019-08-26', 20000, 'Makassar', 20000, 'Jalan Lompeteke Dusun Kalumpang Utara Desa Tritiro', 'sudah kirim pembayaran', NULL),
(4, 2, 4, '2019-09-03', 95000, 'Jeneponto', 20000, 'Jalan Sumbu utara', 'sudah terkirim', ''),
(5, 2, 2, '2019-09-10', 30000, 'Bulukumba', 15000, 'Jl.Abd Dg.Sirua No.202\r\nPanakukang', 'sudah kirim pembayaran', NULL),
(6, 2, 1, '2019-09-11', 510000, 'Makassar', 25000, 'Jl. Abdesir Kos No.202 samping Zahira Cell\r\nkos No.202', 'sudah kirim pembayaran', NULL),
(7, 6, 1, '2019-09-23', 40000, 'Makassar', 25000, '', 'pending', NULL),
(9, 6, 1, '2019-09-23', 110000, 'Makassar', 25000, '', 'pending', NULL),
(10, 6, 2, '2019-09-23', 100000, 'Bulukumba', 15000, 'adsasdsa', 'pending', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian_produk`
--

CREATE TABLE `pembelian_produk` (
  `id_pembelian_produk` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `berat` int(11) NOT NULL,
  `subberat` int(11) NOT NULL,
  `subharga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembelian_produk`
--

INSERT INTO `pembelian_produk` (`id_pembelian_produk`, `id_pembelian`, `id_produk`, `jumlah`, `nama`, `harga`, `berat`, `subberat`, `subharga`) VALUES
(1, 1, 1, 3, 'Tempat Tissu', 300000, 59, 177, 900000),
(2, 2, 2, 1, 'Talenan', 75000, 85, 85, 75000),
(4, 4, 3, 1, 'Tempat Buah', 75000, 90, 90, 75000),
(5, 5, 4, 1, 'Tempat Toples Kue', 15000, 60, 60, 15000),
(6, 6, 1, 2, 'Tempat Tissu', 100000, 59, 118, 200000),
(7, 6, 2, 1, 'Talenan', 85000, 85, 85, 85000),
(8, 6, 6, 1, 'Bossara', 200000, 45, 45, 200000),
(9, 7, 4, 1, 'Tempat Toples Kue', 15000, 60, 60, 15000),
(11, 9, 2, 1, 'Talenan', 85000, 85, 85, 85000),
(12, 10, 2, 1, 'Talenan', 85000, 85, 85, 85000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `berat_produk` int(11) NOT NULL,
  `foto_produk` varchar(100) NOT NULL,
  `deskripsi_produk` text NOT NULL,
  `stok_produk` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `harga_produk`, `berat_produk`, `foto_produk`, `deskripsi_produk`, `stok_produk`) VALUES
(1, 'Tempat Tissu', 100000, 59, '2.png', 'Hiasilah produk rumah Anda ', 15),
(2, 'Talenan', 85000, 85, '17.png', 'Kualitas bagus dan tahan lama', 10),
(3, 'Tempat Buah', 75000, 90, '1.png', 'Kuat dan menarik', 19),
(4, 'Tempat Toples Kue', 15000, 60, '20.png', 'Bagus untuk hiasan toples', 8),
(5, 'Pot Hiasan', 40000, 35, '19.png', 'Bagus untuk hiasan rumah ', 6),
(6, 'Bossara', 200000, 45, '16.png', 'Cantik dan Awet', 1),
(8, 'Bakul Besar', 75000, 56, '18.png', 'Cantik dan desain menarik', 15),
(9, 'Alas Piring', 350000, 56, '14.png', 'Alas Piring untuk Setengah Lusin', 5),
(10, 'Alas Gelas', 50000, 34, '10.jpg', 'untuk harga setengah lusin', 10),
(16, 'Bakul Tempat Nasi', 75000, 43, '6.png', 'Cocok untuk penyimpanan Nasi', 20),
(17, 'Toples Sedang', 50000, 23, '9.jpg', 'Cocok untuk penyimpanan Kue', 24),
(19, 'Toples Mini', 35000, 23, '12.png', 'Bagus kualitasnya', 23),
(20, 'Tempat Alat Tulis', 50000, 32, '7.png', 'Bagus untuk Anak di rumah', 15),
(21, 'Tempat Botol', 50000, 25, '8.jpg', 'Bagus untuk hiasan tempat botol', 10),
(22, 'Tempat Sampah', 50000, 26, '21.png', '', 5),
(23, 'Tempat Cake Besar', 150000, 34, '3.png', 'Bagus untuk acara besar', 8),
(24, 'Tempat Aksesoris', 75000, 32, '4.png', 'Sesuai kebutuhan saja', 10),
(25, 'Toples Besar', 80000, 34, '5.png', 'Bagus untuk penyimpanan yang memerlukan ruang besar', 15);

-- --------------------------------------------------------

--
-- Struktur dari tabel `profilukm`
--

CREATE TABLE `profilukm` (
  `id_ukm` int(11) NOT NULL,
  `nama_ukm` varchar(100) NOT NULL,
  `fotostruktural` varchar(255) NOT NULL,
  `nomorhp` varchar(22) NOT NULL,
  `alamat_lengkap` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `profilukm`
--

INSERT INTO `profilukm` (`id_ukm`, `nama_ukm`, `fotostruktural`, `nomorhp`, `alamat_lengkap`) VALUES
(2, 'Atap Konjo', 'struktural.jpg', '082143746481', '1. Visi \r\nUntuk mempelopori Masyarakat untuk berperan  aktif dalam pemberdayaan dengan tujuan menghimpun potensi-potensi yang ada di Desa \r\nMengupayakan kesejahteraan masyarakat \r\nBerperan Aktif membantu Pemerintah melestraikan potensi yang ada\r\n2. Misi \r\nDengan adanya upaya melestarikan potensi yang ada disekitarnya, yang begitu kaya akan sumber daya alam sehingga mampu menhasilkan karya kerajinan yang baik dan bermutu tinggi sehingga layak untuk dipasarkan  baik lokal maupun luar untuk mensejahterakan Masyarakat\r\nMelestarikan kembali warisan leluhur yang sudah dikerjakan turun temurun.\r\n'),
(5, 'Nelayan kecil', 'IMG_9850.JPG', '08124384589', 'Jalan Samboang No 19, Desa Tritiro, Kecamatan Bontotiro, Kabupaten Bulukumba'),
(7, 'Menjahit', 'ibu darma.png', '085298409217', 'Jalan Lompoteke No 4, Dusun Kalumpang Utara Desa Tritiro Kecamatan Bontotiro Kabupaten Bulukumba'),
(8, 'Kuliner', 'ibuyuyun.jpg', '085656209762', 'Jalan Lompoteke No 5, Dusun Kalumpang Utara Desa Tritiro Kecamatan Bontotiro Kabupaten Bulukumba');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telepon` varchar(12) NOT NULL,
  `alamat` text NOT NULL,
  `level` enum('admin','pelanggan') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama`, `username`, `password`, `email`, `telepon`, `alamat`, `level`) VALUES
(1, 'Suriani', 'admin', 'admin', 'Suriani@gmail.com', '081263567273', 'Makassar', 'admin'),
(2, 'lincebidang', 'lincebidang', 'lincebidang', 'lincebidang@gmail.com', '087623562273', 'Makassar', 'pelanggan'),
(4, 'Yuyun', 'yuyun', 'yuyun', 'yuyun@gmail.com', '081243546356', 'Jalan Lampoteke Dusun Kalumpang Utara', 'pelanggan'),
(5, 'nana', 'nana maya', '12345', 'nana@gmail.com', '08274658686', 'Bulukumba', 'pelanggan'),
(6, 'Karlina', 'Lina', 'lina1', 'karlina0029@gmail.com', '085311840731', 'Jl. Toddopuli X', 'pelanggan');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `ongkir`
--
ALTER TABLE `ongkir`
  ADD PRIMARY KEY (`id_ongkir`);

--
-- Indeks untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `id_pembelian` (`id_pembelian`);

--
-- Indeks untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`),
  ADD KEY `id_pelanggan` (`id_pelanggan`),
  ADD KEY `id_ongkir` (`id_ongkir`);

--
-- Indeks untuk tabel `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  ADD PRIMARY KEY (`id_pembelian_produk`),
  ADD KEY `id_pembelian` (`id_pembelian`),
  ADD KEY `id_produk` (`id_produk`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indeks untuk tabel `profilukm`
--
ALTER TABLE `profilukm`
  ADD PRIMARY KEY (`id_ukm`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `ongkir`
--
ALTER TABLE `ongkir`
  MODIFY `id_ongkir` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  MODIFY `id_pembelian_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT untuk tabel `profilukm`
--
ALTER TABLE `profilukm`
  MODIFY `id_ukm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`id_pembelian`) REFERENCES `pembelian` (`id_pembelian`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD CONSTRAINT `pembelian_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `tb_user` (`id_user`) ON UPDATE CASCADE,
  ADD CONSTRAINT `pembelian_ibfk_2` FOREIGN KEY (`id_ongkir`) REFERENCES `ongkir` (`id_ongkir`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  ADD CONSTRAINT `pembelian_produk_ibfk_1` FOREIGN KEY (`id_pembelian`) REFERENCES `pembelian` (`id_pembelian`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
