-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2019 at 04:31 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `si_ukmdesatritiro`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id_berita` int(11) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` date NOT NULL,
  `foto` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id_berita`, `judul`, `isi`, `tanggal`, `foto`, `deskripsi`) VALUES
(2, 'Berita 1', 'Atap Konjo Production kembali memperluas jaringan pemasaran Produk dari hasil anyaman tradisional yang terbuat dari daun lontara, harga terjangkau selain itu juga mampu menghiasi peralatan rumah Anda menjadi lebih indah, kegiatan ini dilakukan sekaligus pendekatan kepada pelanggan', '2019-05-21', 'IMG-20190720-WA0042.jpg', 'Nice'),
(3, 'Berita 2', 'Kegitan Produk Atap Konjo Production ini berlangsung di Rumah Jabatan Gubernur Sulawesi Selatan, di samping Kiri Beliau adalah istri dari Bapak Dr. Ir. H.M. Nurdin Abdullah, M.Agr yaitu Hj Liestiaty  Fachruddin', '2019-08-05', 'IMG-20190720-WA0048.jpg', 'Mantap');

-- --------------------------------------------------------

--
-- Table structure for table `ongkir`
--

CREATE TABLE `ongkir` (
  `id_ongkir` int(11) NOT NULL,
  `nama_kota` varchar(100) NOT NULL,
  `tarif` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ongkir`
--

INSERT INTO `ongkir` (`id_ongkir`, `nama_kota`, `tarif`) VALUES
(1, 'Makassar', 25000),
(2, 'Bulukumba', 15000),
(3, 'Gowa', 25000),
(4, 'Jeneponto', 20000),
(5, 'Takalar', 20000),
(6, 'Bantaeng', 15000),
(7, 'Sinjai', 20000),
(8, 'Bone', 25000),
(9, 'Sidrap', 30000);

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_pembelian`, `nama`, `bank`, `jumlah`, `tanggal`, `bukti`) VALUES
(1, 1, 'Lince Bidang', 'BRI', 920000, '2019-08-20', 'ibu y.jpg'),
(2, 3, 'yuyun', 'BRI', 20000, '2019-08-26', 'Activity Diagram Admin.jpg'),
(3, 2, 'Yuyun Wahyuni', 'Mandiri', 135000, '2019-08-26', 'Sequence Diagram Pelanggan.vsdx.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `id_ongkir` int(11) NOT NULL,
  `tanggal_pembelian` date NOT NULL,
  `total_pembelian` int(11) NOT NULL,
  `nama_kota` varchar(100) NOT NULL,
  `tarif` int(11) NOT NULL,
  `alamat_pengiriman` text NOT NULL,
  `status_pembelian` varchar(100) NOT NULL DEFAULT 'pending',
  `resi_pengiriman` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `id_pelanggan`, `id_ongkir`, `tanggal_pembelian`, `total_pembelian`, `nama_kota`, `tarif`, `alamat_pengiriman`, `status_pembelian`, `resi_pengiriman`) VALUES
(1, 2, 1, '2019-08-20', 920000, 'Makassar', 20000, 'Jalan Bontobila VII No 2 Makassar, batua kecamatan Manggala', 'barang dikirim', '78GHK5R8U'),
(2, 4, 1, '2019-08-26', 135000, 'Makassar', 20000, 'Jalan Lompeteke Dusun Kalumpang Utara Desa Tritiro', 'sudah kirim pembayaran', NULL),
(3, 4, 1, '2019-08-26', 20000, 'Makassar', 20000, 'Jalan Lompeteke Dusun Kalumpang Utara Desa Tritiro', 'sudah kirim pembayaran', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_produk`
--

CREATE TABLE `pembelian_produk` (
  `id_pembelian_produk` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `berat` int(11) NOT NULL,
  `subberat` int(11) NOT NULL,
  `subharga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian_produk`
--

INSERT INTO `pembelian_produk` (`id_pembelian_produk`, `id_pembelian`, `id_produk`, `jumlah`, `nama`, `harga`, `berat`, `subberat`, `subharga`) VALUES
(1, 1, 1, 3, 'Tempat Tissu', 300000, 59, 177, 900000),
(2, 2, 2, 1, 'Talenan', 75000, 85, 85, 75000);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `berat_produk` int(11) NOT NULL,
  `foto_produk` varchar(100) NOT NULL,
  `deskripsi_produk` text NOT NULL,
  `stok_produk` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `harga_produk`, `berat_produk`, `foto_produk`, `deskripsi_produk`, `stok_produk`) VALUES
(1, 'Tempat Tissu', 100000, 59, '2.png', 'Hiasilah produk rumah Anda ', 17),
(2, 'Talenan', 85000, 85, '17.png', 'Kualitas bagus dan tahan lama', 14),
(3, 'Tempat Buah', 75000, 90, '1.png', 'Kuat dan menarik', 20),
(4, 'Tempat Toples Kue', 15000, 60, '20.png', 'Bagus untuk hiasan toples', 10),
(5, 'Pot Hiasan', 40000, 35, '19.png', 'Bagus untuk hiasan rumah ', 6),
(6, 'Bossara', 200000, 45, '16.png', 'Cantik dan Awet', 2),
(8, 'Bakul Besar', 75000, 56, '18.png', 'Cantik dan desain menarik', 15),
(9, 'Alas Piring', 350000, 56, '14.png', 'Alas Piring untuk Setengah Lusin', 5),
(10, 'Alas Gelas', 50000, 34, '10.jpg', 'untuk harga setengah lusin', 10),
(16, 'Bakul Tempat Nasi', 75000, 43, '6.png', 'Cocok untuk penyimpanan Nasi', 20),
(17, 'Toples Sedang', 50000, 23, '9.jpg', 'Cocok untuk penyimpanan Kue', 24),
(19, 'Toples Mini', 35000, 23, '12.png', 'Bagus kualitasnya', 23),
(20, 'Tempat Alat Tulis', 50000, 32, '7.png', 'Bagus untuk Anak di rumah', 15),
(21, 'Tempat Botol', 50000, 25, '8.jpg', 'Bagus untuk hiasan tempat botol', 10),
(22, 'Tempat Sampah', 50000, 26, '21.png', '', 5),
(23, 'Tempat Cake Besar', 150000, 34, '3.png', 'Bagus untuk acara besar', 8),
(24, 'Tempat Aksesoris', 75000, 32, '4.png', 'Sesuai kebutuhan saja', 10);

-- --------------------------------------------------------

--
-- Table structure for table `profilukm`
--

CREATE TABLE `profilukm` (
  `id_ukm` int(11) NOT NULL,
  `nama_ukm` varchar(100) NOT NULL,
  `fotostruktural` varchar(255) NOT NULL,
  `nomorhp` varchar(22) NOT NULL,
  `alamat_lengkap` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profilukm`
--

INSERT INTO `profilukm` (`id_ukm`, `nama_ukm`, `fotostruktural`, `nomorhp`, `alamat_lengkap`) VALUES
(2, 'Struktural Atap Konjo', 'struktural.jpg', 'Visi dan Misi', '1. Visi \r\nUntuk mempelopori Masyarakat untuk berperan  aktif dalam pemberdayaan dengan tujuan menghimpun potensi-potensi yang ada di Desa \r\nMengupayakan kesejahteraan masyarakat \r\nBerperan Aktif membantu Pemerintah melestraikan potensi yang ada\r\n2. Misi \r\nDengan adanya upaya melestarikan potensi yang ada disekitarnya, yang begitu kaya akan sumber daya alam sehingga mampu menhasilkan karya kerajinan yang baik dan bermutu tinggi sehingga layak untuk dipasarkan  baik lokal maupun luar untuk mensejahterakan Masyarakat\r\nMelestarikan kembali warisan leluhur yang sudah dikerjakan turun temurun.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telepon` varchar(12) NOT NULL,
  `alamat` text NOT NULL,
  `level` enum('admin','pelanggan') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama`, `username`, `password`, `email`, `telepon`, `alamat`, `level`) VALUES
(1, 'Suriani', 'admin', 'admin', 'Suriani@gmail.com', '081263567273', 'Makassar', 'admin'),
(2, 'lincebidang', 'lincebidang', 'lincebidang', 'lincebidang@gmail.com', '087623562273', 'Makassar', 'pelanggan'),
(4, 'Yuyun', 'yuyun', 'yuyun', 'yuyun@gmail.com', '081243546356', 'Jalan Lampoteke Dusun Kalumpang Utara', 'pelanggan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id_berita`);

--
-- Indexes for table `ongkir`
--
ALTER TABLE `ongkir`
  ADD PRIMARY KEY (`id_ongkir`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `id_pembelian` (`id_pembelian`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`),
  ADD KEY `id_pelanggan` (`id_pelanggan`),
  ADD KEY `id_ongkir` (`id_ongkir`);

--
-- Indexes for table `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  ADD PRIMARY KEY (`id_pembelian_produk`),
  ADD KEY `id_pembelian` (`id_pembelian`),
  ADD KEY `id_produk` (`id_produk`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `profilukm`
--
ALTER TABLE `profilukm`
  ADD PRIMARY KEY (`id_ukm`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id_berita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ongkir`
--
ALTER TABLE `ongkir`
  MODIFY `id_ongkir` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  MODIFY `id_pembelian_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `profilukm`
--
ALTER TABLE `profilukm`
  MODIFY `id_ukm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`id_pembelian`) REFERENCES `pembelian` (`id_pembelian`) ON UPDATE CASCADE;

--
-- Constraints for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD CONSTRAINT `pembelian_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `tb_user` (`id_user`) ON UPDATE CASCADE,
  ADD CONSTRAINT `pembelian_ibfk_2` FOREIGN KEY (`id_ongkir`) REFERENCES `ongkir` (`id_ongkir`) ON UPDATE CASCADE;

--
-- Constraints for table `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  ADD CONSTRAINT `pembelian_produk_ibfk_1` FOREIGN KEY (`id_pembelian`) REFERENCES `pembelian` (`id_pembelian`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
