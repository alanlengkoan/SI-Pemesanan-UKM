<?php

// untuk koneksi ke database
$host   = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "si_ukmdesatritiro";

$koneksi = new mysqli ($host, $dbuser, $dbpass, $dbname);

if ($koneksi->connect_errno) {
    echo "Gagal Koneksi " . $koneksi->connect_error;
} else {
    // echo "Koneksi Berhasil";
}